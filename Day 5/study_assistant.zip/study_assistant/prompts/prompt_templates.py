# # prompts/prompt_templates.py

# # Prompt for summarizing study material
# SUMMARY_PROMPT = """
# You are a study assistant. Summarize the following educational content into concise bullet points:
# Content: {content}
# """

# # Prompt for generating multiple-choice questions
# MCQ_GENERATION_PROMPT = """
# Based on the following summarized content, generate 5 multiple-choice questions.
# Each question must have 4 options (a-d), and one correct answer.
# Format:
# Question: ...
# a) ...
# b) ...
# c) ...
# d) ...
# Answer: [option letter]

# Summarized Content: {summary}
# """

# prompts/prompt_templates.py

SUMMARY_PROMPT = """
You are a study assistant. Summarize the following educational content into concise bullet points:
Content: {content}

Please provide a clear and comprehensive summary that covers the main topics and key points.
"""

MCQ_GENERATION_PROMPT = """
Based on the following summarized content, generate exactly 5 multiple-choice questions.
Each question must have exactly 4 options (a, b, c, d), and one correct answer.

Follow this exact format for each question:

Question: [Your question here]
a) [Option A]
b) [Option B] 
c) [Option C]
d) [Option D]
Answer: [correct option letter]

Make sure each question tests important concepts from the summary.

Summarized Content: {summary}
"""