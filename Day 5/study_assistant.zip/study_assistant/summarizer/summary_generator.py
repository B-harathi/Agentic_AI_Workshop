# from langchain_google_genai import ChatGoogleGenerativeAI
# from prompts.prompt_templates import SUMMARY_PROMPT
# from config import GEMINI_API_KEY

# def generate_summary(content):
#     llm = ChatGoogleGenerativeAI(model="gemini-1.5-flash", google_api_key=GEMINI_API_KEY)
#     prompt = SUMMARY_PROMPT.format(content=content)
#     response = llm.invoke(prompt)
#     return response.content


# summarizer/summary_generator.py

from langchain_google_genai import ChatGoogleGenerativeAI
from prompts.prompt_templates import SUMMARY_PROMPT
from config import GEMINI_API_KEY

def generate_summary(content):
    """Generate a summary of the given content"""
    try:
        llm = ChatGoogleGenerativeAI(
            model="gemini-1.5-flash", 
            google_api_key=GEMINI_API_KEY,
            temperature=0.3
        )
        
        prompt = SUMMARY_PROMPT.format(content=content)
        response = llm.invoke(prompt)
        
        # Extract content from response
        if hasattr(response, 'content'):
            return response.content
        else:
            return str(response)
            
    except Exception as e:
        print(f"Error generating summary: {e}")
        return f"Error generating summary: {e}"