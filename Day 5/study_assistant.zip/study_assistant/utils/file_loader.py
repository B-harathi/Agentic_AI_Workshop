# import os
# import PyPDF2

# def load_content(input_path_or_text):
#     if isinstance(input_path_or_text, str) and os.path.isfile(input_path_or_text) and input_path_or_text.lower().endswith('.pdf'):
#         try:
#             with open(input_path_or_text, 'rb') as file:
#                 reader = PyPDF2.PdfReader(file)
#                 text = ''
#                 for page in reader.pages:
#                     extracted = page.extract_text()
#                     if extracted:
#                         text += extracted
#                 return text
#         except Exception as e:
#             raise ValueError(f"Error reading PDF: {e}")
#     else:
#         return input_path_or_text.strip()

# utils/file_loader.py

import os
import PyPDF2

def load_content(input_path_or_text):
    """Load content from PDF file or return text as-is"""
    if isinstance(input_path_or_text, str) and os.path.isfile(input_path_or_text) and input_path_or_text.lower().endswith('.pdf'):
        try:
            with open(input_path_or_text, 'rb') as file:
                reader = PyPDF2.PdfReader(file)
                text = ''
                for page in reader.pages:
                    extracted = page.extract_text()
                    if extracted:
                        text += extracted + '\n'
                
                if not text.strip():
                    raise ValueError("No text could be extracted from the PDF")
                    
                return text.strip()
                
        except Exception as e:
            raise ValueError(f"Error reading PDF: {e}")
    else:
        return input_path_or_text.strip()