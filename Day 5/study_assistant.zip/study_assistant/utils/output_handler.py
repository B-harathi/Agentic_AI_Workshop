# def save_quiz_to_file(summary, quiz_questions):
#     output = "📌 Summary:\n" + summary + "\n\n📝 Quiz Questions:\n"
#     for idx, q in enumerate(quiz_questions, 1):
#         output += f"\nQuestion {idx}: {q['question']}\n"
#         for opt in ['a', 'b', 'c', 'd']:
#             output += f"{opt}) {q['options'].get(opt, 'N/A')}\n"
#         output += f"Answer: {q['answer']}\n"

#     filename = "output_quiz.txt"
#     with open(filename, "w", encoding="utf-8") as f:
#         f.write(output)
#     return filename

# utils/output_handler.py

def save_quiz_to_file(summary, quiz_questions):
    """Save summary and quiz questions to a text file"""
    output = "📌 SUMMARY:\n"
    output += "=" * 50 + "\n"
    output += summary + "\n\n"
    
    output += "📝 QUIZ QUESTIONS:\n"
    output += "=" * 50 + "\n"
    
    for idx, q in enumerate(quiz_questions, 1):
        output += f"\nQuestion {idx}: {q['question']}\n"
        output += "-" * 30 + "\n"
        
        for opt in ['a', 'b', 'c', 'd']:
            option_text = q['options'].get(opt, 'N/A')
            output += f"{opt.upper()}) {option_text}\n"
        
        output += f"\n✅ Correct Answer: {q['answer'].upper()}\n"
        output += "\n"

    filename = "study_summary_and_quiz.txt"
    
    try:
        with open(filename, "w", encoding="utf-8") as f:
            f.write(output)
        return filename
    except Exception as e:
        print(f"Error saving file: {e}")
        return None