# config.py
GEMINI_API_KEY = "AIzaSyC-0m9Hqa-ov82NOXV13EcZJXbN2Ne8nmc"  # Replace with your actual Gemini API key