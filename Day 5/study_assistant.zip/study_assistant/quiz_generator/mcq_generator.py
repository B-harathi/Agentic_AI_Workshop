# from langchain_google_genai import ChatGoogleGenerativeAI
# from prompts.prompt_templates import MCQ_GENERATION_PROMPT
# from config import GEMINI_API_KEY


# def parse_quiz_response(response_text):
#     if isinstance(response_text, list):
#         response_text = "\n".join(response_text)

#     lines = [line.strip() for line in response_text.split('\n') if line.strip()]
#     questions = []
#     i = 0

#     while i < len(lines):
#         line = lines[i]

#         if line.startswith("Question:"):
#             question = {
#                 "question": line.replace("Question:", "", 1).strip(),
#                 "options": {},
#                 "answer": None
#             }

#             # Try to extract 4 options
#             for j in range(1, 5):
#                 if i + j >= len(lines):
#                     break
#                 opt_line = lines[i + j]
#                 if opt_line.lower().startswith(("a)", "b)", "c)", "d)")):
#                     key = opt_line[0].lower()
#                     question["options"][key] = opt_line[2:].strip()

#             # Look ahead up to 5 lines for Answer
#             found_answer = False
#             for j in range(1, 6):
#                 if i + j >= len(lines):
#                     break
#                 ans_line = lines[i + j]
#                 if ans_line.startswith("Answer:"):
#                     raw_answer = ans_line.replace("Answer:", "").strip()
#                     if raw_answer:
#                         question["answer"] = raw_answer[0].lower()
#                         found_answer = True
#                     break

#             # Only add valid questions
#             if len(question["options"]) == 4 and question["answer"] and found_answer:
#                 questions.append(question)

#         i += 1

#     return questions


# def generate_quiz(summary):
#     """
#     Generates quiz questions using Gemini model.
#     :param summary: Summarized study content
#     :return: List of quiz questions (dictionary format)
#     """
#     llm = ChatGoogleGenerativeAI(model="gemini-1.5-flash", google_api_key=GEMINI_API_KEY)
#     prompt = MCQ_GENERATION_PROMPT.format(summary=summary)

#     try:
#         response = llm.invoke(prompt)
#         quiz_text = response.content if isinstance(response.content, str) else "\n".join(response.content)
#         return parse_quiz_response(quiz_text)
#     except Exception as e:
#         print(f"Error generating quiz: {e}")
#         return []


# quiz_generator/mcq_generator.py

from langchain_google_genai import ChatGoogleGenerativeAI
from prompts.prompt_templates import MCQ_GENERATION_PROMPT
from config import GEMINI_API_KEY
import re

def parse_quiz_response(response_text):
    """Parse the quiz response text into structured questions"""
    if isinstance(response_text, list):
        response_text = "\n".join(response_text)
    
    questions = []
    
    # Split by "Question:" to get individual questions
    question_blocks = re.split(r'Question\s*\d*\s*:', response_text, flags=re.IGNORECASE)
    
    for block in question_blocks[1:]:  # Skip the first empty split
        lines = [line.strip() for line in block.split('\n') if line.strip()]
        
        if not lines:
            continue
            
        question_text = lines[0].strip()
        options = {}
        answer = None
        
        # Extract options and answer
        for line in lines[1:]:
            line = line.strip()
            
            # Check for options (a), b), c), d)
            option_match = re.match(r'^([a-d])\)\s*(.+)', line, re.IGNORECASE)
            if option_match:
                option_key = option_match.group(1).lower()
                option_text = option_match.group(2).strip()
                options[option_key] = option_text
            
            # Check for answer
            answer_match = re.match(r'^Answer\s*:\s*([a-d])', line, re.IGNORECASE)
            if answer_match:
                answer = answer_match.group(1).lower()
        
        # Only add question if it has all required components
        if question_text and len(options) == 4 and answer and answer in options:
            questions.append({
                "question": question_text,
                "options": options,
                "answer": answer
            })
    
    return questions


def generate_quiz(summary):
    """Generate quiz questions based on the summary"""
    try:
        llm = ChatGoogleGenerativeAI(
            model="gemini-1.5-flash", 
            google_api_key=GEMINI_API_KEY,
            temperature=0.3  # Lower temperature for more consistent output
        )
        
        prompt = MCQ_GENERATION_PROMPT.format(summary=summary)
        response = llm.invoke(prompt)
        
        # Extract content from response
        if hasattr(response, 'content'):
            quiz_text = response.content
        else:
            quiz_text = str(response)
        
        # Parse the response into structured questions
        questions = parse_quiz_response(quiz_text)
        
        # Debug: Print raw response if parsing fails
        if not questions:
            print("Raw response:", quiz_text)
            print("Failed to parse questions from response")
        
        return questions
        
    except Exception as e:
        print(f"Error generating quiz: {e}")
        return []