# import streamlit as st
# from utils.file_loader import load_content
# from summarizer.summary_generator import generate_summary
# from quiz_generator.mcq_generator import generate_quiz
# from utils.output_handler import save_quiz_to_file
# import os

# # Page config
# st.set_page_config(page_title="📚 Study Assistant", layout="centered")

# st.title("📚 Study Assistant: PDF/Text → Summary & Quiz")
# st.markdown("Upload a PDF or paste your study material below.")

# # Session state initialization
# if "summary" not in st.session_state:
#     st.session_state.summary = None
# if "quiz" not in st.session_state:
#     st.session_state.quiz = None

# # Input Section
# input_type = st.radio("Choose input type:", ("Upload PDF", "Paste Text"))

# study_content = ""
# if input_type == "Upload PDF":
#     uploaded_file = st.file_uploader("Upload a PDF file", type="pdf")
#     if uploaded_file is not None:
#         with open(os.path.join("temp.pdf"), "wb") as f:
#             f.write(uploaded_file.getbuffer())
#         try:
#             study_content = load_content("temp.pdf")
#         finally:
#             os.remove("temp.pdf")
# else:
#     study_content = st.text_area("Paste your study material here:")

# if study_content.strip():
#     st.success("ContentLoaded successfully!")

#     # Button to generate summary
#     if st.button("🧠 Generate Summary"):
#         with st.spinner("Generating summary..."):
#             summary = generate_summary(study_content)
#             st.session_state.summary = summary
#             st.markdown("### 📝 Summary:")
#             st.write(summary)

#     # Only show quiz button if summary is generated
#     if st.session_state.summary:
#         if st.button("📝 Generate Quiz"):
#             with st.spinner("Generating quiz questions..."):
#                 quiz_questions = generate_quiz(study_content)

#                 if isinstance(quiz_questions, list) and len(quiz_questions) > 0:
#                     st.session_state.quiz = quiz_questions
#                     st.markdown("### ❓ Quiz Questions:")

#                     for idx, q in enumerate(quiz_questions, 1):
#                         st.markdown(f"**{idx}. {q['question']}**")
#                         for opt in ['a', 'b', 'c', 'd']:
#                             st.markdown(f"- **{opt.upper()}**: {q['options'].get(opt, 'N/A')}")
#                         st.markdown(f"✅ **Answer:** {q['answer']}")

#                     # Save and offer download
#                     filename = save_quiz_to_file(st.session_state.summary, st.session_state.quiz)
#                     with open(filename, "r", encoding="utf-8") as f:
#                         file_data = f.read()

#                     st.download_button(
#                         label="⬇️ Download Summary & Quiz",
#                         data=file_data,
#                         file_name=filename,
#                         mime="text/plain"
#                     )
#                 else:
#                     st.error("Failed to generate quiz questions.")
#                     st.warning("The model may have returned unexpected output. Try again or use a different summary.")



# app.py

import streamlit as st
from utils.file_loader import load_content
from summarizer.summary_generator import generate_summary
from quiz_generator.mcq_generator import generate_quiz
from utils.output_handler import save_quiz_to_file
import os
import tempfile

# Page config
st.set_page_config(
    page_title="📚 Study Assistant", 
    layout="centered",
    initial_sidebar_state="collapsed"
)

st.title("📚 Study Assistant: PDF/Text → Summary & Quiz")
st.markdown("Upload a PDF or paste your study material to get an instant summary and quiz questions.")

# Session state initialization
if "summary" not in st.session_state:
    st.session_state.summary = None
if "quiz" not in st.session_state:
    st.session_state.quiz = None
if "content_loaded" not in st.session_state:
    st.session_state.content_loaded = False

# Input Section
st.markdown("### 📝 Input Your Study Material")
input_type = st.radio("Choose input type:", ("Upload PDF", "Paste Text"))

study_content = ""

if input_type == "Upload PDF":
    uploaded_file = st.file_uploader("Upload a PDF file", type="pdf")
    if uploaded_file is not None:
        # Use temporary file
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp_file:
            tmp_file.write(uploaded_file.getbuffer())
            tmp_file_path = tmp_file.name
        
        try:
            study_content = load_content(tmp_file_path)
            st.session_state.content_loaded = True
        except Exception as e:
            st.error(f"Error loading PDF: {e}")
            study_content = ""
        finally:
            # Clean up temporary file
            if os.path.exists(tmp_file_path):
                os.remove(tmp_file_path)
else:
    study_content = st.text_area(
        "Paste your study material here:", 
        height=200,
        placeholder="Paste your notes, articles, or any text content here..."
    )
    if study_content.strip():
        st.session_state.content_loaded = True

# Show content status
if study_content.strip():
    st.success(f"✅ Content loaded successfully! ({len(study_content)} characters)")
    
    # Generate Summary and Quiz Button
    if st.button("🧠 Generate Summary & Quiz", type="primary"):
        
        # Generate Summary
        with st.spinner("📖 Generating summary..."):
            try:
                summary = generate_summary(study_content)
                st.session_state.summary = summary
            except Exception as e:
                st.error(f"Error generating summary: {e}")
                st.stop()
        
        # Generate Quiz
        with st.spinner("❓ Generating quiz questions..."):
            try:
                quiz_questions = generate_quiz(st.session_state.summary)
                
                if quiz_questions and len(quiz_questions) > 0:
                    st.session_state.quiz = quiz_questions
                else:
                    st.error("Failed to generate quiz questions. Please try again.")
                    st.stop()
                    
            except Exception as e:
                st.error(f"Error generating quiz: {e}")
                st.stop()
        
        # Display Results
        st.success("✅ Generated summary and quiz successfully!")

# Display Summary if generated
if st.session_state.summary:
    st.markdown("### 📝 Summary")
    st.markdown("---")
    st.write(st.session_state.summary)

# Display Quiz if generated
if st.session_state.quiz:
    st.markdown("### ❓ Quiz Questions")
    st.markdown("---")
    
    for idx, q in enumerate(st.session_state.quiz, 1):
        st.markdown(f"**Question {idx}: {q['question']}**")
        
        # Display options
        for opt in ['a', 'b', 'c', 'd']:
            option_text = q['options'].get(opt, 'N/A')
            st.markdown(f"**{opt.upper()}**) {option_text}")
        
        # Show answer with styling
        st.markdown(f"<div style='background-color: #e8f5e8; padding: 8px; border-radius: 4px; margin: 10px 0;'><strong>✅ Correct Answer: {q['answer'].upper()}</strong></div>", unsafe_allow_html=True)
        st.markdown("---")

# Download functionality
if st.session_state.summary and st.session_state.quiz:
    st.markdown("### 📥 Download Results")
    
    try:
        filename = save_quiz_to_file(st.session_state.summary, st.session_state.quiz)
        
        if filename and os.path.exists(filename):
            with open(filename, "r", encoding="utf-8") as f:
                file_data = f.read()
            
            st.download_button(
                label="⬇️ Download Summary & Quiz",
                data=file_data,
                file_name=filename,
                mime="text/plain",
                help="Download your summary and quiz questions as a text file"
            )
            
            # Clean up the file after offering download
            os.remove(filename)
        else:
            st.error("Failed to create download file.")
            
    except Exception as e:
        st.error(f"Error creating download: {e}")

# Instructions/Help section
with st.expander("ℹ️ How to use this app"):
    st.markdown("""
    1. **Choose your input method**: Upload a PDF file or paste text directly
    2. **Click 'Generate Summary & Quiz'**: The app will create both a summary and quiz questions
    3. **Review the results**: Read through the summary and quiz questions
    4. **Download**: Save your summary and quiz as a text file for offline use
    
    **Tips:**
    - For best results, use content that is at least 200-300 words long
    - The app works best with educational content like notes, articles, or textbook chapters
    - Quiz questions are generated based on the summary, so ensure your content covers key concepts
    """)

# Reset functionality
if st.session_state.summary or st.session_state.quiz:
    if st.button("🔄 Reset", help="Clear all generated content"):
        st.session_state.summary = None
        st.session_state.quiz = None
        st.session_state.content_loaded = False
        st.rerun()