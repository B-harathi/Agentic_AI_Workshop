from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.prompts import ChatPromptTemplate
from langchain.chains import LLMChain
from langchain.output_parsers import PydanticOutputParser
from pydantic import BaseModel, Field
from typing import List, Dict
import streamlit as st
import json
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class ExpenseAnalysis(BaseModel):
    """Schema for expense analysis output"""
    expense_trends: List[Dict[str, str]] = Field(description="List of expense trends with specific percentages and comparisons")
    areas_of_concern: List[Dict[str, str]] = Field(description="List of areas of concern with specific examples")
    optimization_recommendations: List[Dict[str, str]] = Field(description="List of optimization recommendations with specific targets")

def create_expense_analyzer():
    """Create and configure the LangChain expense analyzer"""
    try:
        # Initialize the LLM
        llm = ChatGoogleGenerativeAI(
            model="models/gemini-1.5-flash",
            temperature=0.3,
            google_api_key="AIzaSyCi1Fr-z-A8fDB3ahs8Iduz3nsM1gIOKxk"
        )

        # Create the output parser
        parser = PydanticOutputParser(pydantic_object=ExpenseAnalysis)

        # Create the prompt template
        template = """
        You are a financial analyst specializing in expense analysis. Analyze the following expense data and provide specific, actionable insights:

        EXPENSE DATA:
        {expense_data}

        {format_instructions}

        Please provide a detailed analysis in the following format:

        1. EXPENSE TRENDS
        - Compare each category's spending against industry standards
        - Identify any categories that are significantly above or below industry averages
        - Provide specific percentage differences where applicable

        2. AREAS OF CONCERN
        - List specific categories or departments with unusually high spending
        - Identify any suspicious patterns or anomalies
        - Provide concrete examples from the data

        3. OPTIMIZATION RECOMMENDATIONS
        - Provide specific, actionable cost reduction strategies
        - Include target percentages for potential savings
        - Suggest alternative vendors or approaches where applicable

        Please be specific and use actual numbers from the data in your analysis. Do not use placeholders or generic statements.
        """

        prompt = ChatPromptTemplate.from_template(template)

        # Create the chain
        chain = LLMChain(
            llm=llm,
            prompt=prompt,
            output_parser=parser
        )

        return chain, parser

    except Exception as e:
        st.error(f"Error creating expense analyzer: {str(e)}")
        return None, None

def analyze_expenses_with_langchain(expense_data: str) -> dict:
    """
    Analyze expenses using LangChain and Gemini
    
    Args:
        expense_data (str): Formatted expense data string
        
    Returns:
        dict: Analysis results
    """
    try:
        # Create the analyzer
        chain, parser = create_expense_analyzer()
        
        if chain is None or parser is None:
            return {
                "error": "Failed to create expense analyzer"
            }

        # Run the analysis
        result = chain.invoke({
            "expense_data": expense_data,
            "format_instructions": parser.get_format_instructions()
        })

        # Convert the result to a dictionary if it's not already
        if isinstance(result, dict):
            return result
        else:
            # Try to parse the result as JSON if it's a string
            try:
                return json.loads(str(result))
            except:
                # If parsing fails, return a structured error
                return {
                    "error": "Failed to parse analysis results",
                    "raw_result": str(result)
                }

    except Exception as e:
        error_message = str(e)
        if "404" in error_message:
            return {"error": "Error: Gemini API model not found. Please check your API configuration."}
        elif "401" in error_message:
            return {"error": "Error: Invalid API key. Please check your API configuration."}
        else:
            return {"error": f"Error analyzing expenses: {error_message}"}
