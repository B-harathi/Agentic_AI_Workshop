import os
import google.generativeai as genai
from dotenv import load_dotenv
import pandas as pd
import streamlit as st

# Load environment variables
load_dotenv()

# Configure Gemini API
try:
    api_key = "AIzaSyCi1Fr-z-A8fDB3ahs8Iduz3nsM1gIOKxk"
    genai.configure(api_key=api_key)
    
    # List available models
    for m in genai.list_models():
        if 'generateContent' in m.supported_generation_methods:
            print(f"Available model: {m.name}")
except Exception as e:
    st.error(f"Error configuring Gemini API: {str(e)}")

def analyze_benchmarks(df):
    """
    Analyze expense patterns against industry benchmarks using Gemini API.
    
    Args:
        df (pandas.DataFrame): Processed expense data
        
    Returns:
        str: Analysis results
    """
    if df.empty:
        return "No data available for analysis."
    
    try:
        # Prepare summary statistics
        summary = {
            'total_expenses': df['amount'].sum(),
            'avg_expense': df['amount'].mean(),
            'expenses_by_category': df.groupby('category')['amount'].sum().to_dict(),
            'expenses_by_department': df.groupby('department')['amount'].sum().to_dict(),
            'top_vendors': df.groupby('vendor')['amount'].sum().nlargest(5).to_dict()
        }
        
        # Create prompt for Gemini
        prompt = f"""
        You are a financial analyst specializing in expense analysis. Analyze the following expense data and provide specific, actionable insights:

        EXPENSE DATA:
        Total Expenses: ${summary['total_expenses']:,.2f}
        Average Expense: ${summary['avg_expense']:,.2f}
        
        Expenses by Category:
        {summary['expenses_by_category']}
        
        Expenses by Department:
        {summary['expenses_by_department']}
        
        Top 5 Vendors:
        {summary['top_vendors']}

        Please provide a detailed analysis in the following format:

        1. EXPENSE TRENDS
        - Compare each category's spending against industry standards
        - Identify any categories that are significantly above or below industry averages
        - Provide specific percentage differences where applicable

        2. AREAS OF CONCERN
        - List specific categories or departments with unusually high spending
        - Identify any suspicious patterns or anomalies
        - Provide concrete examples from the data

        3. OPTIMIZATION RECOMMENDATIONS
        - Provide specific, actionable cost reduction strategies
        - Include target percentages for potential savings
        - Suggest alternative vendors or approaches where applicable

        Please be specific and use actual numbers from the data in your analysis. Do not use placeholders or generic statements.
        """
        
        # Generate response using Gemini
        model = genai.GenerativeModel('models/gemini-1.5-flash')
        
        # Configure generation parameters
        generation_config = {
            "temperature": 0.3,  # Lower temperature for more focused responses
            "top_p": 0.8,
            "top_k": 40,
            "max_output_tokens": 2048,
        }
        
        response = model.generate_content(
            prompt,
            generation_config=generation_config
        )
        
        if response.text:
            return response.text
        else:
            return "No analysis could be generated. Please try again."
    
    except Exception as e:
        error_message = str(e)
        if "404" in error_message:
            return "Error: Gemini API model not found. Please check your API configuration."
        elif "401" in error_message:
            return "Error: Invalid API key. Please check your GEMINI_API_KEY in the .env file."
        else:
            return f"Error analyzing benchmarks: {error_message}"
