import streamlit as st
import pandas as pd
from datetime import datetime, timedelta
import plotly.express as px
from data_loader import load_expense_data
from anomaly_detector import detect_anomalies
from benchmark_analyzer import analyze_benchmarks
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Set page config
st.set_page_config(
    page_title="Expense Pattern Auditor",
    page_icon="💰",
    layout="wide"
)

# Title and description
st.title("Expense Pattern Auditor")
st.markdown("""
This tool helps analyze expense patterns, detect anomalies, and compare against industry benchmarks.
Upload your expense data to get started.
""")

# File uploader
uploaded_file = st.file_uploader("Upload Expense Data (CSV)", type=['csv'])

if uploaded_file is not None:
    # Load and process data
    df = load_expense_data(uploaded_file)
    
    if df.empty:
        st.error("No valid data found in the uploaded file. Please check the file format and try again.")
    else:
        # Sidebar filters
        st.sidebar.header("Filters")
        
        # Date range filter
        date_range = st.sidebar.selectbox(
            "Select Date Range",
            ["This Week", "This Month", "Last Month", "Last 6 Months", "This Year", "Custom"]
        )
        
        if date_range == "Custom":
            start_date = st.sidebar.date_input("Start Date", datetime.now() - timedelta(days=30))
            end_date = st.sidebar.date_input("End Date", datetime.now())
        else:
            # Calculate date range based on selection
            end_date = datetime.now()
            if date_range == "This Week":
                start_date = end_date - timedelta(days=7)
            elif date_range == "This Month":
                start_date = end_date.replace(day=1)
            elif date_range == "Last Month":
                start_date = (end_date.replace(day=1) - timedelta(days=1)).replace(day=1)
            elif date_range == "Last 6 Months":
                start_date = end_date - timedelta(days=180)
            else:  # This Year
                start_date = end_date.replace(month=1, day=1)
        
        # Filter data based on date range
        df['date'] = pd.to_datetime(df['date'])
        mask = (df['date'] >= pd.Timestamp(start_date)) & (df['date'] <= pd.Timestamp(end_date))
        filtered_df = df.loc[mask]
        
        if filtered_df.empty:
            st.warning("No data available for the selected date range.")
        else:
            # Additional filters
            vendors = st.sidebar.multiselect("Select Vendors", df['vendor'].unique())
            departments = st.sidebar.multiselect("Select Departments", df['department'].unique())
            
            if vendors:
                filtered_df = filtered_df[filtered_df['vendor'].isin(vendors)]
            if departments:
                filtered_df = filtered_df[filtered_df['department'].isin(departments)]
            
            if filtered_df.empty:
                st.warning("No data available for the selected filters.")
            else:
                # Main content
                col1, col2 = st.columns(2)
                
                with col1:
                    st.subheader("Expense Overview")
                    # Total expenses
                    total_expenses = filtered_df['amount'].sum()
                    st.metric("Total Expenses", f"${total_expenses:,.2f}")
                    
                    # Expenses by category
                    category_expenses = filtered_df.groupby('category')['amount'].sum().reset_index()
                    if not category_expenses.empty:
                        fig_category = px.bar(
                            category_expenses,
                            x='category',
                            y='amount',
                            title='Expenses by Category'
                        )
                        st.plotly_chart(fig_category)
                
                with col2:
                    st.subheader("Vendor Analysis")
                    # Expenses by vendor
                    vendor_expenses = filtered_df.groupby('vendor')['amount'].sum().reset_index()
                    if not vendor_expenses.empty:
                        fig_vendor = px.bar(
                            vendor_expenses,
                            x='vendor',
                            y='amount',
                            title='Expenses by Vendor'
                        )
                        st.plotly_chart(fig_vendor)
                
                # Anomaly Detection
                st.subheader("Anomaly Detection")
                anomalies = detect_anomalies(filtered_df)
                
                if not anomalies.empty:
                    st.dataframe(anomalies)
                    # Export anomalies
                    csv = anomalies.to_csv(index=False)
                    st.download_button(
                        label="Download Anomalies",
                        data=csv,
                        file_name="anomalies.csv",
                        mime="text/csv"
                    )
                else:
                    st.info("No anomalies detected in the selected period.")
                
                # Benchmark Analysis
                st.subheader("Benchmark Analysis")
                benchmark_analysis = analyze_benchmarks(filtered_df)
                st.write(benchmark_analysis)
