import pandas as pd
import numpy as np
from sklearn.ensemble import IsolationForest
from datetime import datetime, timedelta

def detect_anomalies(df, contamination=0.1):
    """
    Detect anomalies in expense data using Isolation Forest algorithm.
    
    Args:
        df (pandas.DataFrame): Processed expense data
        contamination (float): Expected proportion of anomalies in the data
        
    Returns:
        pandas.DataFrame: DataFrame containing only the anomalous expenses
    """
    # Define the expected columns
    expected_columns = ['date', 'amount', 'vendor', 'department', 'category', 
                       'description', 'employee_id']
    
    # Check if DataFrame is empty or has insufficient data
    if df is None or df.empty or len(df) < 2:
        return pd.DataFrame(columns=expected_columns + ['anomaly_score', 'anomaly_reason'])
    
    # Verify all required columns are present
    missing_columns = [col for col in expected_columns if col not in df.columns]
    if missing_columns:
        print(f"Missing required columns: {missing_columns}")
        return pd.DataFrame(columns=expected_columns + ['anomaly_score', 'anomaly_reason'])
    
    try:
        # Create features for anomaly detection
        features = pd.DataFrame()
        
        # Amount-based features
        features['amount'] = df['amount'].astype(float)
        amount_mean = df['amount'].mean()
        amount_std = df['amount'].std()
        if amount_std != 0:
            features['amount_zscore'] = (df['amount'] - amount_mean) / amount_std
        else:
            features['amount_zscore'] = 0
        
        # Time-based features
        features['day_of_week'] = pd.to_datetime(df['date']).dt.dayofweek
        features['day_of_month'] = pd.to_datetime(df['date']).dt.day
        features['month'] = pd.to_datetime(df['date']).dt.month
        
        # Group-based features
        vendor_means = df.groupby('vendor')['amount'].transform('mean')
        vendor_stds = df.groupby('vendor')['amount'].transform('std')
        features['vendor_zscore'] = np.where(
            vendor_stds != 0,
            (df['amount'] - vendor_means) / vendor_stds,
            0
        )
        
        department_means = df.groupby('department')['amount'].transform('mean')
        department_stds = df.groupby('department')['amount'].transform('std')
        features['department_zscore'] = np.where(
            department_stds != 0,
            (df['amount'] - department_means) / department_stds,
            0
        )
        
        # Fill NaN values with 0
        features = features.fillna(0)
        
        # Check if we have enough data for anomaly detection
        if len(features) < 2:
            return pd.DataFrame(columns=expected_columns + ['anomaly_score', 'anomaly_reason'])
        
        # Initialize and fit Isolation Forest
        iso_forest = IsolationForest(
            contamination=min(contamination, 0.5),  # Ensure contamination is not too high
            random_state=42,
            n_estimators=100
        )
        
        # Fit and predict
        anomalies = iso_forest.fit_predict(features)
        
        # Get anomalous records
        anomalous_indices = np.where(anomalies == -1)[0]
        
        if len(anomalous_indices) == 0:
            return pd.DataFrame(columns=expected_columns + ['anomaly_score', 'anomaly_reason'])
        
        anomalous_df = df.iloc[anomalous_indices].copy()
        
        # Add anomaly score and reason
        anomalous_df['anomaly_score'] = -iso_forest.score_samples(features.iloc[anomalous_indices])
        anomalous_df['anomaly_reason'] = anomalous_df.apply(
            lambda row: _get_anomaly_reason(row, df), axis=1
        )
        
        # Sort by anomaly score
        anomalous_df = anomalous_df.sort_values('anomaly_score', ascending=False)
        
        return anomalous_df
    
    except Exception as e:
        print(f"Error in anomaly detection: {str(e)}")
        return pd.DataFrame(columns=expected_columns + ['anomaly_score', 'anomaly_reason'])

def _get_anomaly_reason(row, df):
    """
    Generate a human-readable reason for why an expense is considered anomalous.
    
    Args:
        row (pandas.Series): The anomalous expense record
        df (pandas.DataFrame): The full expense dataset
        
    Returns:
        str: Reason for the anomaly
    """
    try:
        reasons = []
        
        # Check amount
        vendor_data = df[df['vendor'] == row['vendor']]
        if not vendor_data.empty:
            vendor_mean = vendor_data['amount'].mean()
            if row['amount'] > vendor_mean * 2:
                reasons.append(f"Amount (${row['amount']:.2f}) is more than double the average for {row['vendor']}")
        
        # Check frequency
        if not df.empty:
            date_range = (df['date'].max() - df['date'].min()).days
            if date_range > 0:
                vendor_count = df[df['vendor'] == row['vendor']].shape[0]
                avg_frequency = vendor_count / date_range
                if avg_frequency > 0:
                    recent_count = df[
                        (df['vendor'] == row['vendor']) & 
                        (df['date'] >= row['date'] - timedelta(days=30))
                    ].shape[0]
                    if recent_count > avg_frequency * 2:
                        reasons.append(f"Unusually frequent expenses with {row['vendor']} in the last 30 days")
        
        # Check department
        dept_data = df[df['department'] == row['department']]
        if not dept_data.empty:
            dept_mean = dept_data['amount'].mean()
            if row['amount'] > dept_mean * 2:
                reasons.append(f"Amount is more than double the average for {row['department']} department")
        
        return " | ".join(reasons) if reasons else "Multiple factors contributed to this anomaly"
    
    except Exception as e:
        return f"Error generating anomaly reason: {str(e)}"
