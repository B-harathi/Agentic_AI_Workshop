# Expense Pattern Auditor

A Python-based tool for analyzing expense patterns, detecting anomalies, and comparing against industry benchmarks using the Gemini API.

## Features

- Upload and process expense data (CSV format)
- Interactive dashboard with filtering capabilities
- Anomaly detection using machine learning
- Industry benchmark comparison using Gemini API
- Export functionality for flagged anomalies

## Setup

1. Clone the repository:
```bash
git clone <repository-url>
cd expense_pattern_auditor
```

2. Create a virtual environment and activate it:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

4. Create a `.env` file in the root directory and add your Gemini API key:
```
GEMINI_API_KEY=your_api_key_here
```

## Usage

1. Start the Streamlit application:
```bash
streamlit run src/main.py
```

2. Open your web browser and navigate to the provided URL (usually http://localhost:8501)

3. Upload your expense data in CSV format with the following columns:
   - date
   - amount
   - vendor
   - department
   - category
   - description
   - employee_id

4. Use the sidebar filters to analyze specific time periods, vendors, or departments

5. View the dashboard for:
   - Expense overview
   - Vendor analysis
   - Anomaly detection
   - Benchmark analysis

## Data Format

The application expects a CSV file with the following columns:
- date: Date of the expense (YYYY-MM-DD)
- amount: Expense amount (numeric)
- vendor: Name of the vendor
- department: Department name
- category: Expense category
- description: Expense description
- employee_id: Employee identifier

## Contributing

Feel free to submit issues and enhancement requests!
