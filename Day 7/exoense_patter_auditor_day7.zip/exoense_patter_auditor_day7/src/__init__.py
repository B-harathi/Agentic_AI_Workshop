"""
Expense Pattern Auditor - A tool for analyzing expense patterns and detecting anomalies.
"""

__version__ = "1.0.0"
